#!/usr/bin/env python3
import hashlib, secrets

p  = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFC2F
n  = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141
Gx = 0x79BE667EF9DCBBAC55A06295CE870B07029BFCDB2DCE28D959F2815B16F81798
Gy = 0x483ADA7726A3C4655DA4FBFC0E1108A8FD17B448A68554199C47D08FFB10D4B8

def ec_add(P,Q):
    if P is None: return Q
    if Q is None: return P
    x1,y1=P; x2,y2=Q
    if x1==x2 and (y1+y2)%p==0: return None
    m = (3*x1*x1)*pow(2*y1,-1,p)%p if P==Q else (y2-y1)*pow(x2-x1,-1,p)%p
    x3=(m*m-x1-x2)%p; y3=(m*(x1-x3)-y1)%p
    return (x3,y3)

def ec_mul(k,P):
    R=None
    while k>0:
        if k&1: R=ec_add(R,P)
        P=ec_add(P,P); k>>=1
    return R

G=(Gx,Gy)
H=lambda m: int.from_bytes(hashlib.sha256(m).digest(),'big')%n

d     = int(open("/dev/secret/d").read(), 16)
alpha = int(open("/dev/secret/alpha").read(), 16)
beta  = int(open("/dev/secret/beta").read(),  16)
state = int(open("/dev/secret/seed").read(),  16)

Q = ec_mul(d, G)

def sign(msg: bytes):
    global state
    state = (alpha * state + beta) % n
    k = state
    R = ec_mul(k, G)
    r = R[0] % n
    s = (pow(k,-1,n) * (H(msg) + r*d)) % n
    return r, s
